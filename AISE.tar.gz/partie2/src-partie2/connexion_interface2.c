#include <stdio.h>	//printf
#include <string.h>	//strlen
#include <sys/socket.h>	//socket
#include <arpa/inet.h>	//inet_addr
#include <unistd.h>
#include <errno.h>
#include <stdlib.h> 
#define MAX 1024

void func(int sock) 
{
	char buff[MAX];
	char data[MAX];
	FILE * fp; 

		//bzero(buff, sizeof(buff)); 
		printf("msg to send : "); 
		scanf("%s",buff);
		send(sock, buff, sizeof(buff), 0);
		bzero(buff, sizeof(buff)); 
		recv(sock,buff,sizeof(buff),0);
		printf("recu %s",buff);
		 fp =fopen(buff, "r");
		if (fp == NULL) {

   		 perror("[-]Error in reading file.");
		 exit(1);
			}
		else {printf("succes\n");}
                while ( !feof( fp ) ) {
                fgets( data, MAX, fp );
                if ( ferror( fp ) ) {
               fprintf( stderr, "Reading error with code %d\n", errno );
               break;
              }else { printf("%s", data);} } 

} 

