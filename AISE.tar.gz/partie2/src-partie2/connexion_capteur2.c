/*
	C socket server example, handles multiple clients using threads
*/

#include<stdio.h>
#include<string.h>	//strlen
#include<stdlib.h>	//strlen
#include<sys/socket.h>  //used for socket
#include<arpa/inet.h>	//inet_addr
#include<unistd.h>	//write
#include<pthread.h> //for threading , link with lpthread
#include <errno.h> //used for errors
#define MAX 1024
//receiv function 

void func(int sock) 
{ 
   char buff[MAX];
   recv(sock,buff,sizeof(buff),0);
   printf("Message received: %s \n", buff); 
     bzero(buff, MAX); 
   strcpy(buff, "htop");
    if (send(sock, buff, sizeof(buff), 0) == -1) {
          perror("[-]Error in sending file.");
          exit(1);
     }else {printf("file send!"); }
    bzero(buff, MAX); 
        
}


void *connection_handler(void *);
/*
 * This will handle connection for each client
 * */
void *connection_handler(void *socket_desc)
{
	//Get the socket descriptor
	int sock = *(int*)socket_desc;
	int read_size;
	char message[2000];
	//Receive a message from client
        func(sock);
		
	//Free the socket pointer
	free(socket_desc);
	
	return 0;
}

